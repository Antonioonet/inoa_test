﻿using System.Diagnostics;



// Se nao tem um server, cria 

if (!File.Exists("monitor.pid"))
{
var monitor = new ProcessStartInfo
{
    FileName = Environment.ProcessPath!,
    Arguments = "monitor",
    UseShellExecute = false,
};

var processo = Process.Start(monitor)!;
File.WriteAllText("monitor.pid",$"{processo.Id}");

}

if (args.Length == 1 && args[0] == "monitor")
{
    File.WriteAllText("monitor.pid", Environment.ProcessId.ToString());
    try
    {
        await Monitor.RodarAsync();
    }
    finally
    {
        File.Delete("monitor.pid");   
    }
    return;
}
else
{
    var ativo = args[0].ToUpperInvariant();                                    // "PETR4"
    var precoVenda  = decimal.Parse(args[1]);
    var precoCompra = decimal.Parse(args[2]);    
    if (!File.Exists("cotacoes.csv"))

    if (!File.Exists("cotacoes.csv"))
        File.WriteAllText("cotacoes.csv", "ativo,precoVenda,precoCompra\n");


    File.AppendAllText("cotacoes.csv", $"{ativo},{precoVenda},{precoCompra}\n");

}




record TickerListResponse(List<TickerItem> Results);
record TickerItem(string Symbol, string Name, TickerQuote Quote);
record TickerQuote(double? LastPrice, double? ChangePercent, double? Volume, double? MarketCap);

record QuoteResponse(List<QuoteResult> Results);
record QuoteResult(string Symbol, QuoteData Data);
record QuoteData(
    double? RegularMarketPrice,
    double? RegularMarketChangePercent,
    double? RegularMarketDayLow,
    double? RegularMarketDayHigh,
    double? RegularMarketVolume);