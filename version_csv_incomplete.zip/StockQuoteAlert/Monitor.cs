using System.Globalization;
using System.Net.Http.Headers;
using System.Text.Json;
static class Monitor
{
    public static async Task RodarAsync()
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(1));
        var log = new StreamWriter("monitor.log", append: true) { AutoFlush = true };
        Console.SetOut(log);
        Console.SetError(log);
        do
        {

            var linhas = File.ReadAllLines("cotacoes.csv");    // string[]: one item per line


            var token = Environment.GetEnvironmentVariable("BRAPI_TOKEN") // define isso no terminal 
                ?? throw new InvalidOperationException("Defina a variável BRAPI_TOKEN");

            using var http = new HttpClient { BaseAddress = new Uri("https://brapi.dev") }; 
            // cria um objeto pra fazer requisicao http
            // esse BaseAddress faz toda requiscao comecar com esse endereco

            http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            // loga com meu token 
            var json = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

            var listaDeAtivos = new List<string>();      
            var listaDePrecoVenda = new List<double>();  
            var listaDePrecoCompra = new List<double>();  

            foreach (var linha in linhas.Skip(1))           
            {
                var partes = linha.Split(',');                 

                listaDeAtivos.Add(partes[0]); 
                listaDePrecoVenda.Add(double.Parse(partes[1]));
                listaDePrecoCompra.Add(double.Parse(partes[2]));
            }

          

            // 1) busca pelo nome
            var simbolos = string.Join(",", listaDeAtivos); 
            var cotacao = JsonSerializer.Deserialize<QuoteResponse>(await http.GetStringAsync($"/api/v2/stocks/quote?symbols={simbolos}"), json)!;

            for (int i = 0; i < cotacao.Results.Count; i++)
            {
                var resultado = cotacao.Results[i];
                var simbolo = resultado.Symbol;
                var preco   = resultado.Data.RegularMarketPrice;
                
                
            }


            // 2) cotação completa
            var cotacao = JsonSerializer.Deserialize<QuoteResponse>(
                await http.GetStringAsync($"/api/v2/stocks/quote?symbols={json}"), json)!;

            var d = cotacao.Results[0].Data;
            Console.WriteLine($"""

                {cotacao.Results[0].Symbol}
                Preço:   R$ {d.RegularMarketPrice:F2}
                Variação: {d.RegularMarketChangePercent:+0.00;-0.00}%
                Dia:     R$ {d.RegularMarketDayLow:F2} - R$ {d.RegularMarketDayHigh:F2}
                Volume:  {d.RegularMarketVolume:N0}
                """);
        }
        while (await timer.WaitForNextTickAsync());
    }
}
